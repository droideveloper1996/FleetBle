package com.demo.fleetstudioble

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [WearableDataModel::class], version = 1)
abstract class FleetDatabase : RoomDatabase() {
    abstract fun wearableDao(): WearableDao
}