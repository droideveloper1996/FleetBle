package com.demo.fleetstudioble

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class WearableDataModel(

    @PrimaryKey(autoGenerate = true) val id: Int,
    @ColumnInfo(name = "pulse")
    val pulse: String?,
    @ColumnInfo(name = "energy")
    val energy: String?,
    @ColumnInfo(name = "time")
    val time: String?,
    @ColumnInfo(name = "isSensorConnected")
    val isSensorConnected: String?
)
