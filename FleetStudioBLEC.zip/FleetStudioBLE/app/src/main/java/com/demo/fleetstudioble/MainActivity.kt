package com.demo.fleetstudioble

import android.Manifest.permission.*
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.messaging.FirebaseMessaging
import com.welie.blessed.*
import kotlinx.coroutines.*
import org.json.JSONObject
import java.lang.Runnable
import java.util.*


class MainActivity : AppCompatActivity(), DeviceRecyclerViewAdapter.LeDeviceClickInterface {
    private val SCAN_PERIOD: Long = 10000
    private var isNotificationEnabled: Boolean = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var centralManager: BluetoothCentralManager;
    val HEART_RATE_CHARACTERISTIC_UUID =
        UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb")
    val HEART_RATE_NOTIFY_SERVICE_UUID = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb")
    val HEART_RATE_WRITE_CHARACTERISTIC_UUID =
        UUID.fromString("00002a39-0000-1000-8000-00805f9b34fb")
    val READ_CHARACTERISTIC_UUID =
        UUID.fromString("00002a00-0000-1000-8000-00805f9b34fb")
    val READ_SERVICE_UUID = UUID.fromString("00001800-0000-1000-8000-00805f9b34fb")
    private lateinit var fleetDatabase: FleetDatabase
    private lateinit var builder: AlertDialog;

    private lateinit var wearableDao: WearableDao

    @OptIn(DelicateCoroutinesApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        wearableDao = DatabaseBuilder.getInstance(this).wearableDao()
        setContentView(R.layout.activity_main)
        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.w("TAG", "Fetching FCM registration token failed", task.exception)
                return@OnCompleteListener
            }
            val token = task.result
            Log.d("Token", token)
        })


        checkPermissions()
        checkGPSIsOpen()
        centralManager = BluetoothCentralManager(this)
        var deviceMap = HashMap<String, BluetoothPeripheral>()
        centralManager.scanForPeripherals({ peripheral, scanResult ->
            Log.d("Device", peripheral.address)
            deviceMap.put(peripheral.address, peripheral)
        }, { scanFailure: ScanFailure ->

        })

        var progressIndicator = findViewById<LinearLayout>(R.id.progressIndicator)
        var recyclerview = findViewById<RecyclerView>(R.id.recyclerview)


        Handler().postDelayed(Runnable {
            progressIndicator.visibility = View.GONE
            var deviceList: ArrayList<BluetoothPeripheral> = arrayListOf()
            deviceMap.forEach {
                deviceList.add(it.value)
            }
            var adapter = DeviceRecyclerViewAdapter(this, deviceList, this)
            recyclerview.layoutManager = LinearLayoutManager(this)
            recyclerview.adapter = adapter

            centralManager.stopScan()
        }, SCAN_PERIOD)

        centralManager.observeConnectionState { peripheral, state ->
            Log.d("Peripheral", " ${peripheral.address} has $state")

            if (state.toString() == "CONNECTED") {
                var ch = peripheral.getNotifyingCharacteristics()
                var services = peripheral.services
                services.forEach {
                    Log.d("Services", " ${it.uuid} has ${it.type}")
                }
                runOnUiThread(Runnable {
                    showConsole(peripheral)
                })
            }
        }

    }

    private fun showConsole(peripheral: BluetoothPeripheral) {
        var data = ""
        builder = AlertDialog.Builder(this, R.style.CustomAlertDialog)
            .create()
        val view = layoutInflater.inflate(R.layout.ble_device_console, null)
        val notifyButton = view.findViewById<Button>(R.id.getNotifyPermission)
        val readButton = view.findViewById<Button>(R.id.getReadPermission)
        val consoleView = view.findViewById<TextView>(R.id.console)
        val clear_console = view.findViewById<TextView>(R.id.clear_text)
        val msg_box = view.findViewById<TextView>(R.id.message_box)
        clear_console.setOnClickListener {
            consoleView.text = ""
            data = ""
        }
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(builder.getWindow()?.getAttributes())
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = 800
        var notificationCharacteristic = peripheral.getCharacteristic(
            HEART_RATE_NOTIFY_SERVICE_UUID,
            HEART_RATE_CHARACTERISTIC_UUID
        )
        notifyButton.setOnClickListener {
            if (!isNotificationEnabled) {
                notificationCharacteristic?.let {
                    scope.launch {
                        peripheral.observe(it) { value ->
                            "Received : $value".also {
                                consoleView.text = ""
                                data = HeartRateMeasurement.fromBytes(value)
                                    .toString() + data + '\n' + "----------------------" + '\n'
                                consoleView.text = data
                                convertJson(HeartRateMeasurement.fromBytes(value))


                            }
                            Log.d("OUTPUT", HeartRateMeasurement.fromBytes(value).toString())
                        }
                    }
                }
            } else {
                scope.launch {
                    peripheral.stopObserving(notificationCharacteristic!!)
                }
            }
            isNotificationEnabled = !isNotificationEnabled


        }

        readButton.setOnClickListener {

            scope.launch {
                val model = peripheral.readCharacteristic(
                    READ_SERVICE_UUID,
                    READ_CHARACTERISTIC_UUID
                ).asString()

                "Received : $model".also {
                    consoleView.text = ""
                    data += it + '\n'
                    consoleView.text = data

                }
                Log.d("MODEL", "Received: $data")
            }
        }

        view.findViewById<ImageView>(R.id.send).setOnClickListener {
            var text = msg_box.text.toString()
            if (text.isNotEmpty()) {
                scope.launch {
                    "Sent : $text".also {
                        consoleView.text = ""
                        data += it + '\n'
                        consoleView.text = data

                    }
                    msg_box.text = ""
                    peripheral.writeCharacteristic(
                        HEART_RATE_NOTIFY_SERVICE_UUID,
                        HEART_RATE_WRITE_CHARACTERISTIC_UUID,
                        text.toByteArray(),
                        WriteType.WITH_RESPONSE
                    )
                }
            }
        }



        builder.setView(view)
        builder.setCanceledOnTouchOutside(false)
        builder.show()
        val width = (resources.displayMetrics.widthPixels * 0.90).toInt()
        val height = (resources.displayMetrics.heightPixels * 0.90).toInt()

        builder.getWindow()?.setLayout(width, height)
    }

    override fun onDestroy() {
        super.onDestroy()
        builder.dismiss()
    }

    private fun checkPermissions() {

        val permission2 =
            ActivityCompat.checkSelfPermission(this, BLUETOOTH_SCAN)
        if (permission2 != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(BLUETOOTH_SCAN, ACCESS_FINE_LOCATION, BLUETOOTH_CONNECT),
                1
            )
        }
    }


    private fun checkGPSIsOpen(): Boolean {
        val locationManager = this.getSystemService(LOCATION_SERVICE) as LocationManager
            ?: return false
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
    }

    override fun onDeviceSelected(device: BluetoothPeripheral) {
        scope.launch {
            try {
                centralManager.connectPeripheral(device)
            } catch (connectionFailed: ConnectionFailedException) {
                Log.d("TAG", "connection failed")
            }
        }
    }


    private fun convertJson(measurement: HeartRateMeasurement) {

        scope.launch {
            wearableDao.insert(
                WearableDataModel(
                    0,
                    measurement.pulse.toString(),
                    measurement.energyExpended.toString(),
                    measurement.createdAt.toString(),
                    measurement.sensorContactStatus.toString()
                )
            )

        }
        var data = HashMap<String, String>()
        data.put("pulse", measurement.pulse.toString())
        data.put("energy", measurement.energyExpended.toString())
        data.put("isSensorConnected", measurement.sensorContactStatus.name)
        data.put("time", measurement.createdAt.toString())
        var jsonObject: JSONObject = JSONObject(data as Map<*, *>?)
        Log.d("JSON Object", jsonObject.toString())

        var retrofit = RetrofitClient.getInstance()
        var apiInterface = retrofit.create(ApiInterface::class.java)
        lifecycleScope.launchWhenCreated {
            try {
                val response = apiInterface.sendWearableData(jsonObject)
                if (response.isSuccessful()) {
                    //your code for handaling success response


                } else {
                    Toast.makeText(
                        this@MainActivity,
                        response.errorBody().toString(),
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (Ex: Exception) {
                Log.e("Error", Ex.localizedMessage)
            }
        }

    }

}