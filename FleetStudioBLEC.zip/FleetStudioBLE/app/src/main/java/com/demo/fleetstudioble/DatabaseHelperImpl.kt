package com.demo.fleetstudioble

class DatabaseHelperImpl(private val gfgDatabase: FleetDatabase) {
//    override suspend fun getCourses(): List<WearableDataModel> = gfgDatabase.WearableDao().getAll()
//    override suspend fun insertAll(Courses: List<WearableDataModel>) = gfgDatabase.WearableDao().insertAll(Courses)
}