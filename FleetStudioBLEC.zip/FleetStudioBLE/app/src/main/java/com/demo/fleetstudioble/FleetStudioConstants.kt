package com.demo.fleetstudioble

import java.util.*

object FleetStudioConstants {



    val HEART_RATE_READ_SERVICE_UUID = UUID.fromString("")
    val HEART_RATE_READ_CHARACTERISTIC_UUID = UUID.fromString("")

    val HEART_RATE_WRITE_SERVICE_UUID = UUID.fromString("")
    val HEART_RATE_WRITE_CHARACTERISTIC_UUID = UUID.fromString("")


}