package com.demo.fleetstudioble

import org.json.JSONObject
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiInterface {
    @POST("/sendWearableData")
    suspend fun sendWearableData(@Body body: JSONObject): Response<HeartRateApiResponse>
}