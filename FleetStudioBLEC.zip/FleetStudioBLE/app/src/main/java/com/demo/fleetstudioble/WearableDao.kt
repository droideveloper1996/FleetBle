package com.demo.fleetstudioble

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface WearableDao {


    @Query("SELECT * FROM WearableDataModel")
     fun getAll(): List<WearableDataModel>

    @Insert
     fun insertAll(list: List<WearableDataModel>)

    @Insert
     fun insert(data: WearableDataModel)

    @Delete
     fun delete(data: WearableDataModel)

}