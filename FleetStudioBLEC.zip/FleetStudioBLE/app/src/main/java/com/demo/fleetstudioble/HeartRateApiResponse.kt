package com.demo.fleetstudioble

import com.google.gson.annotations.SerializedName

class HeartRateApiResponse {
    @SerializedName("status")
    var status: String = ""

    @SerializedName("email")
    var msg: String = ""
}
