package com.demo.fleetstudioble

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.welie.blessed.BluetoothPeripheral

class DeviceRecyclerViewAdapter(
    val context: Context,
    var list: List<BluetoothPeripheral>,
    listner: LeDeviceClickInterface
) :
    RecyclerView.Adapter<DeviceRecyclerViewAdapter.DeviceViewHolder>() {
    private var listner: LeDeviceClickInterface

    init {
        this.listner = listner
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DeviceViewHolder {
        return DeviceViewHolder(
            LayoutInflater.from(context).inflate(R.layout.item_ble_device, parent, false)
        )
    }

    override fun onBindViewHolder(holder: DeviceViewHolder, position: Int) {
        holder.deviceName.text = list[position].address
        holder.itemView.setOnClickListener {
            listner.onDeviceSelected(list[position])
        }
    }

    override fun getItemCount(): Int {
        return list.size

    }

    interface LeDeviceClickInterface {
        fun onDeviceSelected(
            device: BluetoothPeripheral
        )
    }

    class DeviceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var deviceName = itemView.findViewById<TextView>(R.id.deviceName)
    }
}