package com.demo.fleetstudioble

import android.content.Context
import androidx.room.Room

object DatabaseBuilder {
    private var INSTANCE: FleetDatabase? = null
    fun getInstance(context: Context): FleetDatabase {
        if (INSTANCE == null) {
            synchronized(FleetDatabase::class) {
                INSTANCE = buildRoomDB(context)
            }
        }
        return INSTANCE!!
    }

    private fun buildRoomDB(context: Context) =
        Room.databaseBuilder(
            context.applicationContext,
            FleetDatabase::class.java,
            "FleetWearable.db"
        ).build()
}