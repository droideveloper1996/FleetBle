package com.welie.blessed

data class Phy(val tx: PhyType, val rx: PhyType)