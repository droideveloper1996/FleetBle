const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const mongoose = require("mongoose");
const app = express();
var FCM = require("fcm-push");
const PORT = 8080 | process.env.PORT;
dotenv.config();
app.use(cors());

app.use(express.json());

var deviceToken =
  "dBeVLZ72TR6kByrXORnPMb:APA91bHR0oMCi3JkMk89WkKEzfkKZId5KANLe9x9eObGmMglW64vsPOwP7j15YD4owHnfvSz4NWfDlmQ8ex_jQLxV8pZWAwWJrcA6Um_G4AHvE1RXZsZROk14np2AnemPfEFdKCbP4K0";
var serverKey =
  "AAAAEJjh738:APA91bHow5wQgELPsyKNKWMWYVEJjengY7OjGkpwXkoJThelDRbo7fAYLUHfYjb0lRmlEXc3chmgBzXGLc6QLrLq2Y9tJKW9GD2vtbLbzW4aJkSZDRL52Cwl1lLYGXWnn7L-Mis4LaLS";
var fcm = new FCM(serverKey);

var message = {
  to: deviceToken, // required fill with device token or topics
  collapse_key: "green",
  data: {
    mas: "Updated Data, Notification From FCM Server",
  },
  notification: {
    title: "Title of your push notification",
    body: "Body of your push notification",
  },
};

mongoose.connect(
  process.env.DB_CONNECT_URL_PRODUCTION,
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  },
  (err) => {
    if (err) throw err.message;
    else console.log("Connection was Successful");
  }
);

app.post("/sendWearableData", (req, res) => {
  fcm
    .send(message)
    .then(function (response) {
      console.log("Successfully sent with response: ", response);
    })
    .catch(function (err) {
      console.log("Something has gone wrong!");
      console.error(err);
    });
  return res.status(200).json({ msg: "scsc" });
});

app.listen(PORT, () => {
  console.log("Server is running");
});
